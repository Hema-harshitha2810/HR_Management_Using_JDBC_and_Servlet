package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/add")
public class AddEmp extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out= resp.getWriter();
		out.println("<html><body>");
		out.println("<center>"
				+ "<h1>Enter Employee Details</h1>"
				+ "<form action='addemp'>"
				+ "Id: <input name='id'><br> "
				+ "Email:<input name='email'><br>");

		out.println("Name: <input name='name' ><br>");
		out.println("Mobile: <input name='mob' ><br>");
		out.println("Job: <input name='job' ><br>"
				+ "<button>Submit</button></form></center>");
		out.println("</body></html>");
	}
}
