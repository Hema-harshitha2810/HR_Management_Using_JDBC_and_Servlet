package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/addemp")
public class AddEmployeeDetails extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int id=Integer.parseInt(req.getParameter("id"));
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		String job=req.getParameter("job");
		long mobile= Long.parseLong(req.getParameter("mob"));
		
		Connection conn=null;
		PreparedStatement ps=null;
		PrintWriter out = resp.getWriter();
		out.println("<html><body>");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/advance_java","root","root");
			ps=conn.prepareStatement("insert into emp values(?,?,?,?,?)");
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setString(3, job);
			ps.setString(4, email);
			ps.setLong(5, mobile);
			int res =ps.executeUpdate();
			if(res>0)
			{
				out.println("<center><h1>Successfully Added</h1></center>");
			}
			else
			{
				RequestDispatcher rd=req.getRequestDispatcher("add");
				out.print("<h1>Failed...Try Again</h1>");
				rd.include(req, resp);
			}
		} 
		
		catch (ClassNotFoundException | SQLException e) {
			RequestDispatcher rd=req.getRequestDispatcher("add");
			out.print("<h1>Technical Issue...Try Again</h1>");
			rd.include(req, resp);
//			e.printStackTrace();
		}
		out.println("</body></html>");
	}
}
