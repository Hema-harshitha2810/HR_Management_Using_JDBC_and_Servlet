package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/displayall")
public class DisplayAll extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Connection conn=null;
		PreparedStatement ps=null;
		PrintWriter out=resp.getWriter();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/advance_java","root","root");
			ps=conn.prepareStatement("select * from emp");
			ResultSet rs=ps.executeQuery();
			out.println("<html><body><table border>");
			out.println("<tr><th>Emp ID</th><th>Emp Name</th><th>Job Title</th><th>Email</th><th>Mobile</th><th colspan='2'>Operation</th></tr>");
			while(rs.next())
			{
				out.println("<tr><td>"+rs.getInt(1)+"</td>"
						+ "<td>"+rs.getString(2)+"</td>"
						+ "<td>"+rs.getString(3)+"</td>"
						+ "<td>"+rs.getString(4)+"</td>"
						+ "<td>"+rs.getLong(5)+"</td>"
						+ "<td><form action='edit'><input name='id' value="+rs.getInt(1)+" hidden><button>Edit</button></form></td>"
						+ "<td><form action='deleteemp'><input name='id' value="+rs.getInt(1)+" hidden><button>Delete</button></form></td>"
						+ "</tr>");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		out.println("</table></body></html>");
	}
}
