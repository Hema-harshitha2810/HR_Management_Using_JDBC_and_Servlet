package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/displaypage")
public class DisplayPage extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		out.println("<html><body>");
		out.println("<center><h1>Display a Employee</h1><form action='displayemp'>"
				+ "<input placeholder='Enter ID' name='id'><br>"
				+ "<button>Submit</button>"
				+ "</form></center>");
		out.println("</body></html>");
	}
}
