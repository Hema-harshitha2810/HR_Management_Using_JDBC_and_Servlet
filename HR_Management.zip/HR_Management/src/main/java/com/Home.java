package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/home")
public class Home extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session= req.getSession();
		String name = (String) session.getAttribute("name");
		String email = (String) session.getAttribute("email");
		session.setAttribute("name", name);
		session.setAttribute("email", email);
		PrintWriter out = resp.getWriter();
		out.println("<html><body>");
		out.println("<h1>Welcome, "+name+"</h1>");
		out.println("<form action='profile' method='get'><button>Profile</button></form><br>"
				+ "<form action='add' method='get'><button>Add Employee</button></form><br>"
				+ "<form action='displaypage' method='get'><button>Display a Record</button></form><br>"
				+ "<form action='displayall' method='get'><button>Display All</button></form><br>"
				+ "<form action='deletepage' method='get'><button>Delete a Record</button></form><br>"
				+ "<form action='logout'><button>Logout</button></form>");
		
		out.println("</body></html>");
	}
}
