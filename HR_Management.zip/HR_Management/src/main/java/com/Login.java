package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class Login extends HttpServlet {
	Connection conn=null;
	PreparedStatement ps=null;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email=req.getParameter("email");
		String password=req.getParameter("pwd");
		PrintWriter out = resp.getWriter();
		out.println("<html><body>");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/advance_java","root","root");
			ps=conn.prepareStatement("select * from hrdata where email=?");
			ps.setString(1, email);
			ResultSet resultSet=ps.executeQuery();
			if(resultSet.next())
			{
				if(password.equals(resultSet.getString(2)))
				{
					HttpSession session=req.getSession();
					session.setAttribute("name", resultSet.getString(3));
					session.setAttribute("email", email);
					RequestDispatcher rd=req.getRequestDispatcher("home");
					rd.forward(req, resp);
				}
				else
				{
					out.println("<center><h1>Invalid Password</h1></center>");
					RequestDispatcher rd=req.getRequestDispatcher("Login.html");
					rd.include(req, resp);
				}
			}
			else
			{
				out.println("<center><h1>Invalid Email</h1></center>");
				RequestDispatcher rd=req.getRequestDispatcher("Login.html");
				rd.include(req, resp);
			}
		} catch (ClassNotFoundException | SQLException e) {
			out.print("<h1>Technical Issue...Try Again</h1>");
			RequestDispatcher rd=req.getRequestDispatcher("Login.html");
			rd.include(req, resp);
//			e.printStackTrace();
			
		}
		out.println("</body></html>");
	}
}
