package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/updateemp")
public class UpdateEmp extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Connection conn=null;
		PreparedStatement ps=null;
		PrintWriter out=resp.getWriter();
		out.println("<html><body>");
		
		int id=Integer.parseInt(req.getParameter("id"));
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		String job=req.getParameter("job");
		long mobile= Long.parseLong(req.getParameter("mob"));
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/advance_java","root","root");
			ps=conn.prepareStatement("update emp set  ename=?, job=?, eemail=?, emobile=? where eid=?");
			
			ps.setString(1, name);
			ps.setString(2, job);
			ps.setString(3, email);
			ps.setLong(4, mobile);
			ps.setInt(5, id);
			
			int res= ps.executeUpdate();
			if(res>0)
			{
				out.println("<center><h1>Updated Successfully</h1></center>");
			}
			else
			{
				RequestDispatcher rd=req.getRequestDispatcher("edit");
				out.println("Updation Failed...Try Again");
				rd.include(req, resp);
			}
		} catch (ClassNotFoundException | SQLException e) {
			RequestDispatcher rd=req.getRequestDispatcher("edit");
			out.println("Database Problem...Try Again");
			rd.include(req, resp);
		}
		out.println("</body></html>");
	}
}
