package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/updatehr")
public class UpdateHR extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Connection conn=null;
		PreparedStatement ps =null;
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		String password=req.getParameter("pwd");
		long mobile=Long.parseLong(req.getParameter("mob"));
		double salary=Double.parseDouble(req.getParameter("sal"));
		PrintWriter out = resp.getWriter();
		out.println("<html><body>");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/advance_java","root","root");
			ps=conn.prepareStatement("update hrdata set name=?, password=?,mobile=?,salary=? where email=? ");
			ps.setString(1, name);
			ps.setString(2, password);
			ps.setLong(3, mobile);
			ps.setDouble(4, salary);
			ps.setString(5, email);
			int res = ps.executeUpdate();
			if(res>0)
			{
				RequestDispatcher rd=req.getRequestDispatcher("home");
				rd.forward(req, resp);
			}
			else
			{
				RequestDispatcher rd=req.getRequestDispatcher("profile");
				out.print("<h1>Upadation Failed...Try Again</h1>");
				rd.include(req, resp);
			}
		} catch (ClassNotFoundException | SQLException e) {
			RequestDispatcher rd=req.getRequestDispatcher("profile");
			out.print("<h1>Technical Issue...Try Again</h1>");
			rd.include(req, resp);
		}
		out.println("</body></html>");
	}
}
